1.0.1 / 2016-08-17
=================
  * [Deps] update `es5-shim`, `es6-shim`, `object.getownpropertydescriptors`
  * [Dev Deps] update `tape`
  * [Docs] Update things that are now stage 4
  * [Tests] move tests into test dir
  * [Tests] add `npm run lint`

1.0.0 / 2016-03-24
=================
  * Initial release.
