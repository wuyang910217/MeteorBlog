'use strict';

// var test = require('tape');

require('../');
