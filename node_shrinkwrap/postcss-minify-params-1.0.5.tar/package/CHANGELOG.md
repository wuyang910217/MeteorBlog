# 1.0.1

* Refactor to ES6.

# 1.0.0

* Initial release.
