# Uniqid Browserify Example
Tested with Browserify 13.0.1.

![Uniqid Browserify Example](http://i.imgur.com/ubwYKEt.png)

### Install Browserify
```
npm install browserify -g
```

### Usage
```
browserify main.js -o bundle.js
open index.html
```
