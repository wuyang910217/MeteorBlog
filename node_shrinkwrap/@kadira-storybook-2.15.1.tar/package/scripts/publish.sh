#!/usr/bin/env bash
npm publish --access=public
