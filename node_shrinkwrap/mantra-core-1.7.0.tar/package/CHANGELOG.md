# Change Log

### v1.7.0

* Update react-storybook to v1.9.0 to support stubbing.

### v1.6.1
01-May-2016

* Fix action bounding issue with module.load
### v1.6.0
01-May-2016

* Add actions to module.load()

### v1.5.0
09-April-2016

* Updated deps to support React v15.x.x

### v1.4.0
30-March-2016

* Update react-komposer to v1.7.0

### v1.3.0
16-March-2016

* Add support for React Native. This is basically by updating dependencies.

### v1.2.0
* Make module.load() optional.

### v1.1.0

* Update react-komposer to 1.3.0.
* Use react to use 0.14.6 or higher

### v1.0.0

* Initial release
