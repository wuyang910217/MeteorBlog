'use strict';

module.exports = require('react/lib/ReactDOMServer');
