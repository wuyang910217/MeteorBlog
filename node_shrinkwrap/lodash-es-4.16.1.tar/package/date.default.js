import now from './now.js';

export default {
  now
};
