## Changelog

### v2.1.0
1 Sep 2016

* Make the options param on Collection.get method optional

### v2.0.1
31 Aug 2016

* Export the Database class by as the default export

### v2.0.0
31 Aug 2016

* Update the interface to be similar to that of Channel

### v1.0.0
31 Aug 2016

* Implement the planned API
