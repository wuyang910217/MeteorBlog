console.log('Im just a separate entry point! All alone!');

if (module.hot) {
  module.hot.accept();
}
