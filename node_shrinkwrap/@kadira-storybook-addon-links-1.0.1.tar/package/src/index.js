export const ADDON_ID = 'kadirahq/storybook-addon-links';
export const EVENT_ID = `${ADDON_ID}/link-to-message`;

export { register } from './manager';
export { linkTo } from './preview';
