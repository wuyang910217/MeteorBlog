require('./dist').register();
