// Uncomment to register defaults
// import '@kadira/storybook/addons';

// Use the line below to register this addon
// import '@kadira/storybook-addon-links/register';
import '../register';
