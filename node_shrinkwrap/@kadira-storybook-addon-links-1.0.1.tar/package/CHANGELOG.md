## Changelog

### v1.0.1

* Refactor source code
* Update the README file

### v1.0.0

* First stable release with all features from the storybook linkTo function
