Math.max(1,
         2,
         3,
);
