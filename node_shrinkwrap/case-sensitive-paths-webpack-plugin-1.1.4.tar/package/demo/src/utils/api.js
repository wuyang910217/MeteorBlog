export default function() {
  console.log('Hello, universe.');
};