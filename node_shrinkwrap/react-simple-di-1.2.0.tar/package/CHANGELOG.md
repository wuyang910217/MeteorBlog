# ChangeLog

### v1.2.0

* Update React to v15.0.0

### v1.1.0

* Add support for React Native. See [PR4](https://github.com/kadirahq/react-simple-di/pull/4)

### v1.0.1
* Fix issue of re-binding context to action multiple times as we apply context multiple time.
See: [#2](https://github.com/kadirahq/react-simple-di/issues/2)

### v1.0.0

Initial Version.
