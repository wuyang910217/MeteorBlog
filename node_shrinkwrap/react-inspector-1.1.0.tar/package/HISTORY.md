## 1.0.0 (03/02/2016)
- Breaking change: rename from `react-object-inspector` to `react-inspector`
- Adds `TableInspector`

## 0.2.0 (11/26/2015)
- issue #4: inline styles
- issue #5: Initial expanded paths

## 0.1.6 (10/26/2015)
- Upgrade to React 0.14

## 0.1.5 (09/10/2015)
- Display dates in string form
- Resolve issue #6 "undefined" is rendered as Object

## 0.1.0 (08/06/2015)
- Initial release.
