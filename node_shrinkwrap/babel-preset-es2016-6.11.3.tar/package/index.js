module.exports = {
  plugins: [
    require("babel-plugin-transform-exponentiation-operator"),
  ]
};
