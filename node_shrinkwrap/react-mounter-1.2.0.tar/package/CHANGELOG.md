# Change Log

### v1.2.0
2015-April-09

* Add support for React v15.0.0

### v1.1.0
2016-Feb-18

* Add SSR support with FlowRouter's SSR apis.

### v1.0.0

Initial Release
