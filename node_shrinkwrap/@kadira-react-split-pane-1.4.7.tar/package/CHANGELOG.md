# Change Log

## v1.4.0
03-May-2016

* Remove vendor prefixes to support better SSR support.
* Also changed some code styles.
