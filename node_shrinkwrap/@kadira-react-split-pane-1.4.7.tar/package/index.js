var SplitPane = require('./lib/SplitPane');

module.exports = SplitPane;