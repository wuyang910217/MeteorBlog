import { configure } from '@kadira/storybook';

configure(function () {
  require('./stories/SplitPane');
}, module);
