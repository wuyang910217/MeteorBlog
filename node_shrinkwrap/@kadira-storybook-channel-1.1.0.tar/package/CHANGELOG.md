## Changelog

### v1.1.0

* Add a new `from` field to events to identify sender.
* Ignore messages originated from itself (check event.from)

### v1.0.1

* Implement an API similar to an EventEmitter
