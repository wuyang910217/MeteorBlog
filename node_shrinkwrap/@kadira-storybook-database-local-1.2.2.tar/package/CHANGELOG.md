## Changelog

### v1.2.2
19 Sep 2016

* Refactor code and remove `dist`

### v1.2.1
9 Sep 2016

* Add a polyfill for the fetch API [PR4](https://github.com/kadirahq/storybook-database-local/pull/4)

### v1.2.0
2 Sep 2016

* Add a persister which uses a static json file [PR1](https://github.com/kadirahq/storybook-database-local/pull/1)

### v1.1.0
1 Sep 2016

* Add the required express middleware

### v1.0.3
31 Aug 2016

* Add missing headers (content-type)

### v1.0.2
31 Aug 2016

* Fix Illegal Invocation error (fetch)

### v1.0.1
31 Aug 2016

* Update dependencies (fixes critical bug)

### v1.0.0
31 Aug 2016

* Implement the channel persister interface
