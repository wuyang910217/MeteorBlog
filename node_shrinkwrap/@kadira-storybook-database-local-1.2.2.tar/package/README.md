# Local Database

Local database for Kadira Storybooks. This database can be used when developing Storybooks on local machine.

```js
import createDatabase from '@kadira/storybook-database-local'
const db = createDatabase({ url: 'http://localhost:9001/db' })
```
