import * as storybook from '@kadira/storybook';
storybook.configure(() => require('./stories'), module);
