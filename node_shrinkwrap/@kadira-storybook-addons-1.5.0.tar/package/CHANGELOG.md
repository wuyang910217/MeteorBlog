## Changelog

### v1.5.0
13 Aug 2016

* Add `getDatabase` and `setDatabase` methods [PR3](https://github.com/kadirahq/storybook-addons/pull/3)

### v1.4.0
29 Aug 2016

* Add `getPreview` and `setPreview` methods [PR2](https://github.com/kadirahq/storybook-addons/pull/2)

### v1.3.1

* First stable release with addon store for loaders, panels and channel.
