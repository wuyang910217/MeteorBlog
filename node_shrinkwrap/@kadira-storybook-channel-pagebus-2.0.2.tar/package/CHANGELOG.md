## Changelog

### v2.0.2

* Publish the npm module public

### v2.0.0

* Export a `createChannel` function as the default export (breaking change)

### v1.0.1

* Implement send and receive functions
