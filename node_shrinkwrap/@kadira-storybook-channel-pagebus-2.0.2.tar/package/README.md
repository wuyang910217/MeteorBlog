# Pagebus Transport

Pagebus transport for `@kadira/storybook-channel`. This transport can be used when the Storybook Renderer runs inside an iframe or a child window.
